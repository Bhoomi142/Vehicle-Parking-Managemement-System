# VehicleParking
A website which allows the user to book a parking slot inside jssstu campus at various locations with different user groups

How to run the Vehicle Parking Management System Project using PHP and MySQL

Software Required - XAMPP for SQL server and database connection.

1. Download the project zip file

2. Extract the file and copy vpark folder

3. Paste inside root directory(for xampp xampp/htdocs, for wamp wamp/www, for lamp var/www/Html)

4. Open PHPMyAdmin (http://localhost/phpmyadmin)

5. Create a database with the name VehicleParking

6. Download and Import Vehicle VehicleParking.sql file

7. Run the script http://localhost/vpark

8. Landing Page of the project is first.php file. 

Admin Credentials :

Username: admin123

Password: Admin@1234

or Register a new user.

